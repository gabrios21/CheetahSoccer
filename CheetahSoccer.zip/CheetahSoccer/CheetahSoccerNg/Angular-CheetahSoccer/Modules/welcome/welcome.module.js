﻿'use strict';

// Define the `cheetahSoccerApp` module
angular.module('welcome', [
    'ngRoute'
]);