﻿namespace CheetahSoccerWebAPI.POCO
{
    public class Court
    {
        public int Id { get; set; }
        public string CourtName { get; set; }
        public string CourtDescription { get; set; }
    }
}