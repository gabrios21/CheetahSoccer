﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CheetahSoccerWebAPI.BusinessLayer
{
    public class Response
    {
        public int statusCode { get; set; }
        public string message { get; set; }
    }
}