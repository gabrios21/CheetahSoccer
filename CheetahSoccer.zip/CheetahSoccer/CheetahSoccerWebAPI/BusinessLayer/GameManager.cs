﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CheetahSoccerWebAPI.BusinessLayer
{
    public class GameManager
    {
    }
}